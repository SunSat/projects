package com.sunsat.shareAppController;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppControllerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppControllerApplication.class, args);
	}
}
