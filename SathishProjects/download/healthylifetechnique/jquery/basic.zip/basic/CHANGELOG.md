### 1.0.0 - 06/13/2015

- Initial release compatible with Sequence.js 2
