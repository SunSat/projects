### 1.0.0 - 09/12/2015

- Initial release compatible with Sequence.js 2
